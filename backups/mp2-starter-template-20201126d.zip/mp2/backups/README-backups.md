
# Backups folder

The zip file in this folder has a copy of the original starter template files. If you corrupt a file by mistake, you can use the zip file to reset to the original state of the starter code.

You can also download the starter files to your own computer by right-clicking on the zip file and selecting "Download".
